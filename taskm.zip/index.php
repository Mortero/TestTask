<?php

session_start();
date_default_timezone_set('Europe/Moscow');

spl_autoload_register(function($className)
{
    $paths = array('core/','controllers/','models/','views/');
    foreach($paths as $value)
    {
        $classPath = $value.$className.".php";
        if(file_exists($classPath))
        {
            include $classPath;
            break;
        }
    }
});

if(!isset($_SESSION['auth']['logged_in']))
    $_SESSION['auth']['logged_in'] = false;

$Run = new Router;
$Run->Start();