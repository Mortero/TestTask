-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 26 2020 г., 08:30
-- Версия сервера: 10.4.11-MariaDB
-- Версия PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `taskmanager`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `id` int(64) UNSIGNED NOT NULL,
  `owner` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `text` text NOT NULL,
  `is_completed` int(64) UNSIGNED NOT NULL DEFAULT 0,
  `is_edited` int(64) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `owner`, `email`, `text`, `is_completed`, `is_edited`) VALUES
(1, 'test_user', 'test_user@test.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at congue turpis. Sed eu pretium eros, id ultrices risus. Etiam mollis ante felis, vel ornare ante accumsan vel. Etiam sodales arcu eget augue fringilla, vel semper lorem commodo. Pellentesque feugiat molestie egestas. Aliquam non tellus nisl. Cras sit amet dui sed nisi suscipit condimentum. Cras non bibendum lacus. Curabitur in nisl at felis malesuada congue. Aliquam ac hendrerit ligula. Quisque commodo leo ut elementum malesuada.', 0, 1),
(2, 'test_user2', 'test_user2@test.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur et imperdiet velit, in dictum leo. Maecenas vel nisi ac nibh convallis facilisis. Suspendisse aliquam nunc eu convallis iaculis. Sed eleifend molestie dignissim. Phasellus nec dignissim purus. Vivamus iaculis massa nec arcu pharetra, et feugiat mauris efficitur. Aliquam nec ante ultricies velit vestibulum pellentesque at vitae sem. Mauris porta orci et quam interdum hendrerit. In ac tellus a diam faucibus consequat vel vel risus. Curabitur sagittis arcu eu lorem eleifend volutpat. Fusce dapibus lorem at eros mollis ornare. Aenean turpis dui, malesuada non commodo quis, volutpat vitae magna. Suspendisse potenti. Vivamus eu fringilla est, bibendum volutpat eros. Vivamus eu justo mollis, iaculis lacus sit amet, dignissim tortor. Nulla convallis aliquet nulla, sed accumsan dolor.\r\n\r\nSed gravida nisl in diam auctor, sed commodo augue pulvinar. In tempus a sapien eget varius. Mauris quis dictum justo. Sed aliquam nunc purus, vitae finibus magna euismod sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur auctor felis id pretium feugiat. Nulla imperdiet lobortis laoreet.', 0, 0),
(3, 'test_user', 'test_user@test.com', 'Sed gravida nisl in diam auctor, sed commodo augue pulvinar. In tempus a sapien eget varius. Mauris quis dictum justo. Sed aliquam nunc purus, vitae finibus magna euismod sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur auctor felis id pretium feugiat. Nulla imperdiet lobortis laoreet.', 0, 0),
(4, 'test_user3', 'test_user3@test.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur et imperdiet velit, in dictum leo. Maecenas vel nisi ac nibh convallis facilisis. Suspendisse aliquam nunc eu convallis iaculis. Sed eleifend molestie dignissim. Phasellus nec dignissim purus. Vivamus iaculis massa nec arcu pharetra, et feugiat mauris efficitur. Aliquam nec ante ultricies velit vestibulum pellentesque at vitae sem. Mauris porta orci et quam interdum hendrerit. In ac tellus a diam faucibus consequat vel vel risus. Curabitur sagittis arcu eu lorem eleifend volutpat. Fusce dapibus lorem at eros mollis ornare. Aenean turpis dui, malesuada non commodo quis, volutpat vitae magna. Suspendisse potenti. Vivamus eu fringilla est, bibendum volutpat eros. Vivamus eu justo mollis, iaculis lacus sit amet, dignissim tortor. Nulla convallis aliquet nulla, sed accumsan dolor.\r\n\r\nSed gravida nisl in diam auctor, sed commodo augue pulvinar. In tempus a sapien eget varius. Mauris quis dictum justo. Sed aliquam nunc purus, vitae finibus magna euismod sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur auctor felis id pretium feugiat. Nulla imperdiet lobortis laoreet.\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur et imperdiet velit, in dictum leo. Maecenas vel nisi ac nibh convallis facilisis. Suspendisse aliquam nunc eu convallis iaculis. Sed eleifend molestie dignissim. Phasellus nec dignissim purus. Vivamus iaculis massa nec arcu pharetra, et feugiat mauris efficitur. Aliquam nec ante ultricies velit vestibulum pellentesque at vitae sem. Mauris porta orci et quam interdum hendrerit. In ac tellus a diam faucibus consequat vel vel risus. Curabitur sagittis arcu eu lorem eleifend volutpat. Fusce dapibus lorem at eros mollis ornare. Aenean turpis dui, malesuada non commodo quis, volutpat vitae magna. Suspendisse potenti. Vivamus eu fringilla est, bibendum volutpat eros. Vivamus eu justo mollis, iaculis lacus sit amet, dignissim tortor. Nulla convallis aliquet nulla, sed accumsan dolor.\r\n\r\nSed gravida nisl in diam auctor, sed commodo augue pulvinar. In tempus a sapien eget varius. Mauris quis dictum justo. Sed aliquam nunc purus, vitae finibus magna euismod sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur auctor felis id pretium feugiat. Nulla imperdiet lobortis laoreet.', 0, 0),
(9, 'user4', 'user@test.com', 'Sed gravida nisl in diam auctor, sed commodo augue pulvinar. In tempus a sapien eget varius. Mauris quis dictum justo. Sed aliquam nunc purus, vitae finibus magna euismod sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur auctor felis id pretium feugiat. Nulla imperdiet lobortis laoreet.Sed gravida nisl in diam auctor, sed commodo augue pulvinar. In tempus a sapien eget varius. Mauris quis dictum justo. Sed aliquam nunc purus, vitae finibus magna euismod sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur auctor felis id pretium feugiat. Nulla imperdiet lobortis laoreet.', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(64) UNSIGNED NOT NULL,
  `login` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `is_admin` int(64) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `is_admin`) VALUES
(1, 'admin', 'd9b1d7db4cd6e70935368a1efb10e377', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(64) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(64) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
