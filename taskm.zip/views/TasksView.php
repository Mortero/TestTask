<?php


class TasksView
{
    private $WORK_PATH = 'Tasks';
    public $documentTitle = '';

    public function __construct()
    {

    }

    public function getAllTasksPage($data, $page, $pagesCnt, $itemsToPage, $sortLinksArr)
    {
        $this->documentTitle = "Список задач";
        include 'content/html/header.php';
        if(!empty($_SESSION['auth']['is_admin'])) {
            include "content/html/$this->WORK_PATH/tasksAdmin.template.php";
            include "content/html/pagination.php";
        } else {
            include "content/html/$this->WORK_PATH/tasksList.template.php";
            include "content/html/pagination.php";
            include "content/html/$this->WORK_PATH/tasksCreate.template.php";
        }
        include 'content/html/footer.php';
    }
}