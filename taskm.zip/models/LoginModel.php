<?php

class LoginModel
    
{    
    public function Auth($username, $password)
    {
        $db = new Database;
        $username = trim(htmlspecialchars($username));
        $userdata = $this->getUserData($username);
        if(!empty($userdata))
        {
            $password = md5(md5(trim(htmlspecialchars($password))));
            $pwdCheck = hash_equals($userdata['password'], $password);
            if($pwdCheck)
            {
                $_SESSION['auth']['logged_in'] = true;
                foreach ($userdata as $key=>$value)
                {
                    if($key != 'password')
                        $_SESSION['auth'][$key] = $value;
                }
                return true;
            }
            else return false;
        }
        else return false;
        
    }
    
    public function logOut()
    {
        $_SESSION['auth'] = false;
    }
    
    public function createUser($username, $password)
    {
        $db = new Database;
        $username = trim(htmlspecialchars($username));
        $password = md5(md5(trim(htmlspecialchars($password))));
        $result = $this->checkUnique($username);
        if($result)
        {
            // Создание пользователя
            $query = "INSERT into users (login, password) VALUES ('$username', '$password')";
            $result = $db->performQuery($query);
            return $result;
        }
        else return false;
        
    }
    
    public function deleteUser($username)
    {
        $db = new Database;
        $username = trim(htmlspecialchars($username));
        $check = $this->checkUnique($username);
        if(!$check)
        {
            $query = "DELETE FROM users WHERE username = '$username'";
            $result = $db->performQuery($query);
            return $result;
        }
        else return false;
    }
    
    public function checkUnique ($subject)
    {
        $db = new Database;
        $query = "SELECT id FROM users WHERE login = '$subject'";
        $result = $db->performQuery($query);
        return empty($result);
    }
    
    public function getUserData ($username)
    {
        $db = new Database;
        $query = "SELECT * FROM users WHERE login = '$username'";
        $result = $db->performQuery($query);
        return @$result[0];
    }
    
}