<?php


class TasksModel
{
    public $errorMsg = '';

    public function getTasks ($page, $pageLimit, $sortField, $sortOrder)
    {
        if(empty($sortField)) {
            $sortField = 'id';
        }
        if(empty($sortOrder)) {
            $sortOrder = 'asc';
        }
        $query = "SELECT * FROM tasks ORDER BY " . $sortField . " " . strtoupper($sortOrder) . " LIMIT " . $pageLimit;
        if(!empty($page)) {
            $offset = ($page - 1) * $pageLimit;
            $query .= ' OFFSET ' . $offset;
        }

        $db = new Database;
        $result = $db->performQuery($query);
        return $result;
    }

    public function getTaskById (int $id)
    {
        $query = 'SELECT * FROM tasks WHERE id='.$id;
        $db = new Database;
        $result = $db->performQuery($query);
        return $result[0];
    }

    public function createTask ()
    {
        $data = $this->checkFields($_POST);

        if ($data) {
            $query = "INSERT INTO tasks (owner, email, text) VALUES ('" .
                $data['task-input-username'] . "', '" .
                $data['task-input-email'] . "', '" .
                $data['task-input-text'] . "')";
            $db = new Database;
            $result = $db->performQuery($query);
            return true;
        }
    }

    public function editTask ()
    {
        $data = $this->checkFields($_POST);

        if ($data) {
            $query = "UPDATE tasks SET " .
                "owner='" . $data['task-edit-input-username'] ."', ".
                "email='" . $data['task-edit-input-email'] ."', " .
                "text='" . $data['task-edit-input-text']. "', " .
                "is_edited=1";
            if(!empty($_POST['task-edit-input-completion']) && $_POST['task-edit-input-completion'] == 'on') {
                $query .= ", is_completed=1";
            }
            $query .= " WHERE id=".$data['task-edit-input-id'];
            $db = new Database;
            $result = $db->performQuery($query);
            return $result;
        } else {
            return false;
        }
    }

    public function closeTask (int $id)
    {
        $query = "UPDATE tasks SET is_completed=1 WHERE id = " . $id;
        $db = new Database;
        $result = $db->performQuery($query);
    }

    public function checkFields ($usrInput)
    {
        foreach ($usrInput as $key => $val) {
            if($key == 'task-input-email') {
                if(filter_var(strtolower($val), FILTER_VALIDATE_EMAIL)) {
                    $data[$key] = $val;
                } else {
                    $this->errorMsg = 'Вы ввели неправильный e-mail. Проверьте правильность данных и попробуйте снова.';
                    break;
                }
            }
            $data[$key] = htmlspecialchars($val, ENT_QUOTES);
        }
        if (empty($this->errorMsg)) {
            return $data;
        } else {
            return false;
        }
    }

    public function countRecords ()
    {
        $query = 'SELECT COUNT(*) FROM tasks';
        $db = new Database;
        $result = $db->performQuery($query);
        return intval($result[0]['COUNT(*)']);
    }

    public function buildSortLinks ($page, $sortOrder)
    {
        $sortTypes = ['completion', 'name', 'e-mail'];
        foreach ($sortTypes as $item) {
            $sortLinksArr[$item] = "/tasks/?&sort=".$item;
            if($sortOrder == 'asc') {
                $sortLinksArr[$item] .= "&order=desc";
            } else {
                $sortLinksArr[$item] .= "&order=asc";
            }
            $sortLinksArr[$item] .= "&page=".$page;
        }
        return $sortLinksArr;
    }

}