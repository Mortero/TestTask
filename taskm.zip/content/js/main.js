$(function()
{
    $('#login-submit-button').on('click', function(e)
    {
        e.preventDefault();
        $('.login-error-message').remove();

        if(!$('input[name=login]').val()) {
            $('.login-error-message')
            $('input[name=login]').after( "<div class='login-error-message'><p>Имя пользователя не может быть пустым!</p></div>");
        }
        if(!$('input[name=password]').val()) {
            $('input[name=password]').after( "<div class='login-error-message'><p>Пароль не может быть пустым!</p></div>");
        }

        if($('.login-form')[0].checkValidity()) {
            $.ajax(
                {
                    method: "POST",
                    url: $('form').prop('action'),
                    data: { login: $('input[name=login]').val(), password: $('input[name=password]').val(), submit: 'submit' }
                }).done(function(msg)
            {
                if(msg === 'success')
                    window.location.replace("/tasks/");
                else
                {
                    $('#login-submit-button').before("<div class='login-error-message'<p>"+msg+"</p></div>");
                }
            });
        }
    });

});