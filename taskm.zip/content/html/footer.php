    <footer>
        <div class="row">
            <div class="col-md-2 col-md-offset-10 footer-text">
                <span>Тестовое задание, 2020.</span>
            </div>
        </div>
    </footer>

</div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
    <script src="/content/js/main.js"></script>
</body>
</html>
