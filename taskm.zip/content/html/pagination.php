<br>
<div class="row">
    <div class="col-md-12 pagination">
        <?php
        $link = '/tasks/?';
        foreach ($_REQUEST as $attr => $val) {
            static $x = 0;
            if($attr != 'page') {
                if($x) {
                    $link .= '&';
                }
                $link .= $attr."=".$val;
                $x++;
            }
        } ?>
        <?php for($x = 1; $x < $pagesCnt+1; $x++): ?>
            <?php if($x == $page): ?>
                <button type="button" class="btn btn-primary active"><?php echo $x; ?></button>
            <?php else: ?>
            <a class="btn btn-default" href="<?php echo $link."&page=".$x; ?>" role="button"><?php echo $x; ?></a>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
</div>