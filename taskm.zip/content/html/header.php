<?php
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $this->documentTitle;?></title>
    <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link href="/content/css/common.style.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-8 login-block">
            <?php if(isset($_SESSION['auth']['logged_in']) && $_SESSION['auth']['logged_in'] == true) : ?>
                <span>Добро пожаловать, <?php echo $_SESSION['auth']['login']; ?>!</span>
                <a href="/login/logout/">Выйти</a>
            <?php else: ?>
                <form method="post" action="/login/" class="login-form">
                    <div class="form-group">
                        <input type="text" id="login" name="login" placeholder="Логин" required>
                    </div>
                    <div class="form-group">
                        <input type="password" id="password" name="password" placeholder="Пароль" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success" id="login-submit-button">Авторизация</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

