<div class="row editor-block">
    <div class="col-md-4 col-md-offset-4 editor-block-heading">
        <span>Создание новой задачи</span>
    </div>
    <div class="col-md-8 col-md-offset-2">
        <form method="post" action="/tasks/create" name="task-input-field">
            <div class="form-group">
                <label>Имя пользователя</label>
                <input type="text" class="form-control" id="task-creation-username" name="task-input-username" placeholder="Имя пользователя" required>
            </div>
            <div class="form-group">
                <label>E-mail</label>
                <input type="email" class="form-control" id="task-creation-email" name="task-input-email" placeholder="E-mail" required>
            </div>
            <div class="form-group">
                <label>Текст задачи</label>
                <textarea class="form-control" id="task-creation-textarea" name="task-input-text" placeholder="Текст задачи" required></textarea>
            </div>

            <button type="submit" class="btn btn-default">Отправить</button>
        </form>
    </div>
</div>
