<div class="row">
    <div class="col-lg-4 col-lg-offset-4">
        <div class="task-table-header">Список задач</div>
    </div>
    <div class="col-md-12">
        <table class="table table-bordered">
            <tr>
                <th width="4%"><a href="<?php echo $sortLinksArr['completion']; ?>"><div title="Выполнено">
                        <svg class="bi bi-check text-success" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z"/>
                        </svg>
                            <?php if(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'completion' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'asc'): ?>
                                <svg class="bi bi-arrow-down-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" d="M4.646 7.646a.5.5 0 0 1 .708 0L8 10.293l2.646-2.647a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 0 1 0-.708z"/>
                                <path fill-rule="evenodd" d="M8 4.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5z"/>
                            </svg>
                            <?php elseif(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'completion' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'desc'): ?>
                                <svg class="bi bi-arrow-up-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/>
                                    <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8 5.707 5.354 8.354a.5.5 0 1 1-.708-.708l3-3z"/>
                                </svg>
                            <?php endif; ?>
                    </div></a></th>
                <th width="4%"><div title="Отредактировано">
                        <svg class="bi bi-pencil text-info" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z"/>
                            <path fill-rule="evenodd" d="M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z"/>
                        </svg>
                    </div></th>
                <th width="15%"><a href="<?php echo $sortLinksArr['name']; ?>">Имя пользователя</a>
                    <?php if(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'name' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'asc'): ?>
                        <svg class="bi bi-arrow-down-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.646 7.646a.5.5 0 0 1 .708 0L8 10.293l2.646-2.647a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 0 1 0-.708z"/>
                            <path fill-rule="evenodd" d="M8 4.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5z"/>
                        </svg>
                    <?php elseif(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'name' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'desc'): ?>
                        <svg class="bi bi-arrow-up-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/>
                            <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8 5.707 5.354 8.354a.5.5 0 1 1-.708-.708l3-3z"/>
                        </svg>
                    <?php endif; ?>
                </th>
                <th width="15%"><a href="<?php echo $sortLinksArr['e-mail']; ?>">E-mail</a>
                    <?php if(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'e-mail' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'asc'): ?>
                        <svg class="bi bi-arrow-down-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.646 7.646a.5.5 0 0 1 .708 0L8 10.293l2.646-2.647a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 0 1 0-.708z"/>
                            <path fill-rule="evenodd" d="M8 4.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5z"/>
                        </svg>
                    <?php elseif(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'e-mail' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'desc'): ?>
                        <svg class="bi bi-arrow-up-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/>
                            <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8 5.707 5.354 8.354a.5.5 0 1 1-.708-.708l3-3z"/>
                        </svg>
                    <?php endif; ?></th>
                <th width="60%">Текст задачи</th>
            </tr>
            <?php foreach($data as $task): ?>
                <tr>
                    <?php if($task['is_completed']): ?>
                        <td class="success">
                            <svg class="bi bi-check text-success" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z"/>
</svg>
                        </td>
                    <?php else: ?>
                        <td></td>
                    <?php endif ?></td>
                    <?php if($task['is_edited']): ?>
                        <td class="info">
                            <svg class="bi bi-pencil text-info" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z"/>
  <path fill-rule="evenodd" d="M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z"/>
</svg>
                        </td>
                    <?php else: ?>
                        <td></td>
                    <?php endif; ?>
                    <td class="tasks-table-username"><?php echo $task['owner']; ?></td>
                    <td class="tasks-table-email"><?php echo $task['email']; ?></td>
                    <td class="tasks-table-text"><?php echo html_entity_decode($task['text']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
