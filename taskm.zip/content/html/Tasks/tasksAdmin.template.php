<div class="row">
    <div class="col-lg-4 col-lg-offset-4">
        <div class="task-table-header">Список задач</div>
    </div>
    <div class="col-md-12">
        <div class="row editor-block-row">
            <div class="tasks-editor-heading tasks-editor-small" title="Сохранить изменения">
                <svg class="bi bi-pencil text-info" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z"/>
                    <path fill-rule="evenodd" d="M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z"/>
                </svg>
            </div>
            <a href="<?php echo $sortLinksArr['completion']; ?>">
                <div class="tasks-editor-heading tasks-editor-small" title="Выполнено">
                    <svg class="bi bi-check text-success" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z"/>
                    </svg>
                    <?php if(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'completion' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'asc'): ?>
                        <svg class="bi bi-arrow-down-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.646 7.646a.5.5 0 0 1 .708 0L8 10.293l2.646-2.647a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 0 1 0-.708z"/>
                            <path fill-rule="evenodd" d="M8 4.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5z"/>
                        </svg>
                    <?php elseif(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'completion' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'desc'): ?>
                        <svg class="bi bi-arrow-up-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/>
                            <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8 5.707 5.354 8.354a.5.5 0 1 1-.708-.708l3-3z"/>
                        </svg>
                    <?php endif; ?>
                </div>
            </a>
            <a href="<?php echo $sortLinksArr['name']; ?>">
                <div class="tasks-editor-heading tasks-editor-med">
                    Имя пользователя
                    <?php if(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'name' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'asc'): ?>
                        <svg class="bi bi-arrow-down-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.646 7.646a.5.5 0 0 1 .708 0L8 10.293l2.646-2.647a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 0 1 0-.708z"/>
                            <path fill-rule="evenodd" d="M8 4.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5z"/>
                        </svg>
                    <?php elseif(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'name' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'desc'): ?>
                        <svg class="bi bi-arrow-up-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/>
                            <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8 5.707 5.354 8.354a.5.5 0 1 1-.708-.708l3-3z"/>
                        </svg>
                    <?php endif; ?>
                </div>
            </a>
            <a href="<?php echo $sortLinksArr['e-mail']; ?>">
                <div class="tasks-editor-heading tasks-editor-med">
                    E-mail
                    <?php if(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'e-mail' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'asc'): ?>
                        <svg class="bi bi-arrow-down-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.646 7.646a.5.5 0 0 1 .708 0L8 10.293l2.646-2.647a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 0 1 0-.708z"/>
                            <path fill-rule="evenodd" d="M8 4.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5z"/>
                        </svg>
                    <?php elseif(isset($_REQUEST['sort']) && $_REQUEST['sort'] == 'e-mail' && isset($_REQUEST['order']) && $_REQUEST['order'] == 'desc'): ?>
                        <svg class="bi bi-arrow-up-short table-order-indicator" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/>
                            <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8 5.707 5.354 8.354a.5.5 0 1 1-.708-.708l3-3z"/>
                        </svg>
                    <?php endif; ?>
                </div>
            </a>
            <div class="tasks-editor-heading tasks-editor-large">
                Текст задачи
            </div>
        <?php foreach($data as $task): ?>

                <div class="tasks-form-editor-row">
                    <form method="post" action="/tasks/update/" class="tasks-edit-table">
                        <input type="hidden" name="task-edit-input-id" value="<?php echo $task['id']; ?>">
                        <div class="tasks-editor-field tasks-editor-small color-blue">
                            <button  type="submit" class="btn btn-primary tasks-editor-button">
                                <svg class="bi bi-pencil" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z"/>
                                    <path fill-rule="evenodd" d="M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z"/>
                                </svg>
                            </button>
                        </div>
                        <div class="tasks-editor-field tasks-editor-small color-green"><input type="checkbox" name="task-edit-input-completion" <?php if($task['is_completed']) echo 'checked'; ?>></div>
                        <div class="tasks-editor-field tasks-editor-med"><input type="text" class="form-control" id="task-edit-username" name="task-edit-input-username" placeholder="Имя пользователя" value="<?php echo $task['owner']; ?>" required></div>
                        <div class="tasks-editor-field tasks-editor-med"><input type="email" class="form-control" id="task-edit-email" name="task-edit-input-email" placeholder="E-mail" value="<?php echo $task['email']; ?>" required></div>
                        <div class="tasks-editor-field tasks-editor-large"><textarea class="form-control" id="task-edit-textarea" name="task-edit-input-text" placeholder="Текст задачи" required><?php echo html_entity_decode($task['text']); ?></textarea></div>
                    </form>
                </div>
        <?php endforeach; ?>
        </div>
    </div>
</div>
