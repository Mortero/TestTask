<?php

class LoginController
    
{
    private $model;
    private $view;
    private $loginData;
    private $loginErrorMsg = '';
    
    public function __construct ()
    {
        $this->model = new LoginModel;
    }
    
    public function actionDefault ()
    {
        if(!empty($_POST)) {
            $result = $this->model->Auth($_POST['login'], $_POST['password']);
            if($result) {
                echo 'success';
            }
            else {
                $this->loginErrorMsg = 'Неправильное имя пользователя или пароль. Повторите попытку.';
                echo 'Неправильное имя пользователя или пароль. Повторите попытку.';
            }
        } else {
            include '404.php';
        }
        
    }
    
    public function actionLogout ()
    {
        $this->model->logOut();
        header("Location: /tasks/");
    }
    
}