<?php

class TasksController
{
    private $model;
    private $view;
    private $taskData;
    private $tasksToPage = 3;
    private $page = 1;
    private $sortField = 'id';
    private $sortOrder = 'asc';
    private $pagesCnt = 1;

    public function __construct ()
    {
        $this->model = new TasksModel;
        $this->view = new TasksView;
    }

    public function actionDefault ()
    {
        $this->actionPage();
    }

    public function actionView ($data = null)
    {
        // Получение одной записи из БД по id
        $this->taskData['id'] = (int)$data[0];
        $this->taskData = $this->model->getTaskById($this->taskData['id']);
        $this->view->getProductByIdPage($this->productData);
    }

    public function actionCreate ()
    {
        if(!empty($_POST)) {
            if ($this->model->createTask()) {
                header('Location: '.$_SERVER['HTTP_REFERER']);
            } else {
                echo $this->model->errorMsg;
            }
        } else {
            include '404.php';
        }
    }

    public function actionUpdate ()
    {
        if (!empty($_POST)) {
            if($_SESSION['auth']['is_admin']) {
                if ($this->model->editTask()) {
                    header('Location: '.$_SERVER['HTTP_REFERER']);
                } else {
                    echo 'Не удалось обновить задание. Проверьте правильность ввода данных и повторите попытку.';
                }
            } else {
                echo 'Ошибка авторизации. Повторите вход в систему и попробуйте снова.';
            }
        } else {
            include '404.php';
        }
    }

    public function actionPage ()
    {
        $tasksCnt = $this->model->countRecords();
        $this->pagesCnt = ceil($tasksCnt / $this->tasksToPage);

        if(isset($_REQUEST['page'])) {
            if(intval($_REQUEST['page'])) {
                $this->page = intval($_REQUEST['page']);
            }
        }
        if(!empty($_REQUEST['sort'])) {
            switch(strtolower($_REQUEST['sort'])) {
                case 'name':
                    $this->sortField = "owner";
                    break;
                case 'e-mail':
                    $this->sortField = "email";
                    break;
                case 'completion':
                    $this->sortField = 'is_completed';
                    break;
                default:
                    $this->sortField = 'id';
            }
        }
        if(!empty($_REQUEST['order'])) {
            if(strtolower($_REQUEST['order']) == 'desc' || 'asc') {
                $this->sortOrder = strtolower($_REQUEST['order']);
            }
        }

        $this->taskData = $this->model->getTasks($this->page, $this->tasksToPage, $this->sortField, $this->sortOrder);
        $sortLinksArr = $this->model->buildSortLinks($this->page, $this->sortOrder);
        $this->view->getAllTasksPage($this->taskData, $this->page, $this->pagesCnt, $this->tasksToPage, $sortLinksArr);
    }
}