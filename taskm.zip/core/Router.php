<?php

class Router

{
    private $controller;
    private $action;
    private $parameters = null;
    private $controllerPath;
    
    public function __construct ()
    {
        $this->controllerPath = $_SERVER['DOCUMENT_ROOT']. "/controllers/";
    }
    
    public function Start ()
    {
        $params = explode("?", $_SERVER['REQUEST_URI']);
        if(count($params) > 1) {
            $this->parameters = array_pop($params);
        }
        $uri = explode("/", trim($params[0], "/"));
        if($_SERVER['REQUEST_URI'] === '/')
        {
            header("Location: /tasks/");
        }
        else
        {
            $this->controller = ucfirst(array_shift($uri));
            $this->action = array_shift($uri);
        }        

        if(!empty($this->parameters))
        {
            $this->parameters = explode("&", $this->parameters);
        }
        
        if(empty($this->controller) || $this->controller == 'Index.php') {
            $this->controller = 'Tasks';
        }

        $this->controllerPath .= $this->controller  . "Controller.php";
        $this->controller .= 'Controller';
        
        if(!empty($this->action))
        {
            $this->action = "action".ucfirst($this->action);
        }

        if(isset($_SERVER['HTTP_REFERER']))
        {
            define('REFERRER',substr($_SERVER['HTTP_REFERER'], strpos($_SERVER['HTTP_REFERER'], '/', 7)));
        }

        if(file_exists($this->controllerPath))
        {
            $stream = new $this->controller;
            if(method_exists($stream, $this->action))
            {
                $stream->{$this->action}($this->parameters);
            }
            else $stream->actionDefault();
        }
        else include '404.php';
    }    
}