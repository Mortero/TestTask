<?php

class Database
    
{
    private $connection;
    private $errorMsg;
    private $params;
    private $confPath = 'dbconfig.json';
    
    public function __construct ()
    {
        
    }

    private function openConnection ()
    {
        $file = file_get_contents ($this->confPath);
        $this->params = json_decode($file, true);
        $this->connection = mysqli_connect($this->params['HOSTNAME'], $this->params['USERNAME'], $this->params['PASSWORD'], $this->params['DATABASE']);
        if(mysqli_connect_errno($this->connection))
        {
            $this->errorMsg = "Ошибка подключения к MySQL: " . mysqli_connect_error();
        }
        else
        {
            mysqli_query($this->connection,"SET NAMES 'utf8'");
            mysqli_query($this->connection,"SET CHARACTER SET 'utf8'");
        }
    }
    
    private function closeConnection()
    {
        $result = mysqli_close($this->connection);
    }
    
    public function getErrorMessage()
    {
        return $this->errorMsg;
    }
    
    public function performQuery($query)
    {
        $this->openConnection();
        $query = htmlspecialchars($query);
        $temp = mysqli_query($this->connection, $query);
        $this->errorMsg = mysqli_error($this->connection);
        $this->closeConnection();
        if (is_object($temp))
        {
            $result = array();
            while($row = mysqli_fetch_assoc($temp))
            {
                $result[] = $row;
            }
            return $result;
        }
        elseif ($temp === TRUE)
            return true;
        else
            return false;
    }
    
    
    
}